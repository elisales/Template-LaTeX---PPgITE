bibtex monografia
pdflatex monografia.tex
evince monografia.pdf&
